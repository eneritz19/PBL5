package com.example;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;

class QueueEngineTest {

    /**
     * Fake sink para capturar el último update y contar pushes.
     */
    static final class CapturingSink implements UpdateSink {
        final AtomicInteger pushes = new AtomicInteger(0);
        final AtomicReference<QueueUpdate> last = new AtomicReference<>();

        @Override
        public void push(QueueUpdate update) {
            pushes.incrementAndGet();
            last.set(update);
        }
    }

    /**
     * DoctorQueueManager real (no mock) con capacidad suficiente.
     * Esto valida integración: enqueue + buildUpdate + sink.push.
     */
    @Test
    void onIncoming_enqueuesAndPushesUpdate() throws Exception {
        CapturingSink sink = new CapturingSink();
        DoctorQueueManager manager = new DoctorQueueManager(50);

        QueueEngine engine = new QueueEngine(manager, sink);

        PhotoMsg msg = new PhotoMsg("img1", "D1", PhotoMsg.Urgency.MEDIO, 100L);

        engine.onIncoming(msg);

        assertEquals(1, sink.pushes.get(), "Should push exactly once");
        QueueUpdate u = sink.last.get();
        assertNotNull(u);

        assertEquals("D1", u.doctorId);
        assertEquals(1, u.queueOrdered.size());
        assertEquals("img1", u.queueOrdered.get(0).imageCode);
        assertEquals("MEDIO", u.queueOrdered.get(0).urgency);
        assertEquals(100L, u.queueOrdered.get(0).createdAt);

        assertEquals(0, u.sizes.get("ALTO"));
        assertEquals(1, u.sizes.get("MEDIO"));
        assertEquals(0, u.sizes.get("BAJO"));
        assertEquals(1, u.sizes.get("TOTAL"));
    }

    @Test
    void onIncoming_multipleMessages_sameDoctor_ordersByUrgencyThenFifoWithinUrgency() throws Exception {
        CapturingSink sink = new CapturingSink();
        DoctorQueueManager manager = new DoctorQueueManager(50);
        QueueEngine engine = new QueueEngine(manager, sink);

        // creado con timestamps para fijar orden FIFO dentro de la misma urgencia
        engine.onIncoming(new PhotoMsg("low1", "D1", PhotoMsg.Urgency.BAJO, 10L));
        engine.onIncoming(new PhotoMsg("high1", "D1", PhotoMsg.Urgency.ALTO, 20L));
        engine.onIncoming(new PhotoMsg("med1", "D1", PhotoMsg.Urgency.MEDIO, 30L));
        engine.onIncoming(new PhotoMsg("high2", "D1", PhotoMsg.Urgency.ALTO, 40L));

        QueueUpdate u = sink.last.get();
        assertNotNull(u);

        // Esperado (sin aging): ALTO FIFO, luego MEDIO, luego BAJO
        List<String> codes = u.queueOrdered.stream().map(it -> it.imageCode).toList();
        assertEquals(List.of("high1", "high2", "med1", "low1"), codes);

        assertEquals(2, u.sizes.get("ALTO"));
        assertEquals(1, u.sizes.get("MEDIO"));
        assertEquals(1, u.sizes.get("BAJO"));
        assertEquals(4, u.sizes.get("TOTAL"));
    }

    @Test
    void onIncoming_differentDoctors_pushesUpdateForThatDoctor() throws Exception {
        CapturingSink sink = new CapturingSink();
        DoctorQueueManager manager = new DoctorQueueManager(50);
        QueueEngine engine = new QueueEngine(manager, sink);

        engine.onIncoming(new PhotoMsg("a", "D1", PhotoMsg.Urgency.ALTO, 1L));
        QueueUpdate u1 = sink.last.get();
        assertEquals("D1", u1.doctorId);
        assertEquals(1, u1.queueOrdered.size());

        engine.onIncoming(new PhotoMsg("b", "D2", PhotoMsg.Urgency.BAJO, 2L));
        QueueUpdate u2 = sink.last.get();
        assertEquals("D2", u2.doctorId);
        assertEquals(1, u2.queueOrdered.size());

        // Verifica que el estado del manager mantiene ambas colas
        QueueUpdate q1 = manager.buildUpdate("D1");
        QueueUpdate q2 = manager.buildUpdate("D2");
        assertEquals(1, q1.queueOrdered.size());
        assertEquals(1, q2.queueOrdered.size());
        assertEquals("a", q1.queueOrdered.get(0).imageCode);
        assertEquals("b", q2.queueOrdered.get(0).imageCode);

        assertEquals(2, sink.pushes.get(), "Should have pushed once per onIncoming call");
    }
}
