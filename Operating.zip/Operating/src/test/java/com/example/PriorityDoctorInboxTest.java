package com.example;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

import static org.junit.jupiter.api.Assertions.*;

class PriorityDoctorInboxTest {

    @Test
    void snapshotOrdered_ordersByUrgencyAndFifoWithinUrgency() throws Exception {
        PriorityDoctorInbox inbox = new PriorityDoctorInbox("D1", 10);

        // Mezcla de urgencias y timestamps para fijar FIFO dentro de cada cola
        inbox.enqueue(new PhotoMsg("low1", "D1", PhotoMsg.Urgency.BAJO, 10L));
        inbox.enqueue(new PhotoMsg("high1", "D1", PhotoMsg.Urgency.ALTO, 20L));
        inbox.enqueue(new PhotoMsg("med1", "D1", PhotoMsg.Urgency.MEDIO, 30L));
        inbox.enqueue(new PhotoMsg("high2", "D1", PhotoMsg.Urgency.ALTO, 40L));
        inbox.enqueue(new PhotoMsg("med2", "D1", PhotoMsg.Urgency.MEDIO, 50L));
        inbox.enqueue(new PhotoMsg("low2", "D1", PhotoMsg.Urgency.BAJO, 60L));

        List<String> codes = inbox.snapshotOrdered().stream().map(i -> i.imageCode).toList();

        // ALTO (FIFO) -> MEDIO (FIFO) -> BAJO (FIFO)
        assertEquals(List.of("high1", "high2", "med1", "med2", "low1", "low2"), codes);
    }

    @Test
    void sizesSnapshot_countsEachUrgencyAndTotal() throws Exception {
        PriorityDoctorInbox inbox = new PriorityDoctorInbox("D1", 10);

        inbox.enqueue(new PhotoMsg("a", "D1", PhotoMsg.Urgency.ALTO, 1L));
        inbox.enqueue(new PhotoMsg("b", "D1", PhotoMsg.Urgency.MEDIO, 2L));
        inbox.enqueue(new PhotoMsg("c", "D1", PhotoMsg.Urgency.BAJO, 3L));
        inbox.enqueue(new PhotoMsg("d", "D1", PhotoMsg.Urgency.BAJO, 4L));

        Map<String, Integer> sizes = inbox.sizesSnapshot();

        assertEquals(1, sizes.get("ALTO"));
        assertEquals(1, sizes.get("MEDIO"));
        assertEquals(2, sizes.get("BAJO"));
        assertEquals(4, sizes.get("TOTAL"));
    }

    @Test
    void takeNext_returnsHighThenMediumThenLow_andFreesCapacity() throws Exception {
        PriorityDoctorInbox inbox = new PriorityDoctorInbox("D1", 2);

        inbox.enqueue(new PhotoMsg("low", "D1", PhotoMsg.Urgency.BAJO, 10L));
        inbox.enqueue(new PhotoMsg("high", "D1", PhotoMsg.Urgency.ALTO, 20L));

        PhotoMsg first = inbox.takeNext();
        PhotoMsg second = inbox.takeNext();

        assertEquals("high", first.imageCode);
        assertEquals("low", second.imageCode);

        // Al haber consumido 2, debe haber hueco para encolar de nuevo sin bloquear
        inbox.enqueue(new PhotoMsg("x", "D1", PhotoMsg.Urgency.MEDIO, 30L));
        assertEquals(1, inbox.sizesSnapshot().get("TOTAL"));
    }

    @Test
    void removeByImageCode_removesFromAnyDeque_andAdjustsSemaphores() throws Exception {
        PriorityDoctorInbox inbox = new PriorityDoctorInbox("D1", 1);

        inbox.enqueue(new PhotoMsg("img1", "D1", PhotoMsg.Urgency.ALTO, 1L));

        assertEquals(1, inbox.sizesSnapshot().get("TOTAL"));

        boolean removed = inbox.removeByImageCode("img1");
        assertTrue(removed);

        assertEquals(0, inbox.sizesSnapshot().get("TOTAL"));

        // Si el ajuste de semáforos va bien, ahora debería permitir encolar otro (capacidad 1)
        assertDoesNotThrow(() -> inbox.enqueue(new PhotoMsg("img2", "D1", PhotoMsg.Urgency.BAJO, 2L)));
        assertEquals(1, inbox.sizesSnapshot().get("TOTAL"));
    }

    @Test
    void removeByImageCode_missing_returnsFalse_andDoesNotChangeCounts() throws Exception {
        PriorityDoctorInbox inbox = new PriorityDoctorInbox("D1", 2);

        inbox.enqueue(new PhotoMsg("a", "D1", PhotoMsg.Urgency.ALTO, 1L));

        assertFalse(inbox.removeByImageCode("nope"));
        assertEquals(1, inbox.sizesSnapshot().get("TOTAL"));
    }

    @Test
    void capacity_blocksEnqueue_untilTakeNextFreesSlot() throws Exception {
        PriorityDoctorInbox inbox = new PriorityDoctorInbox("D1", 1);

        inbox.enqueue(new PhotoMsg("first", "D1", PhotoMsg.Urgency.BAJO, 1L));

        ExecutorService es = Executors.newSingleThreadExecutor();

        Future<?> blockedEnqueue = es.submit(() -> {
            try {
                inbox.enqueue(new PhotoMsg("second", "D1", PhotoMsg.Urgency.BAJO, 2L));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new RuntimeException(e);
            }
        });

        // Debe estar bloqueado (capacidad 1 llena). Si termina rápido, algo va mal.
        assertThrows(TimeoutException.class, () -> blockedEnqueue.get(150, TimeUnit.MILLISECONDS));

        // Liberamos capacidad consumiendo 1
        PhotoMsg taken = inbox.takeNext();
        assertEquals("first", taken.imageCode);

        // Ahora el enqueue debería completar
        assertDoesNotThrow(() -> blockedEnqueue.get(2, TimeUnit.SECONDS));

        es.shutdownNow();
        assertEquals(1, inbox.sizesSnapshot().get("TOTAL"));
    }

    @Test
    void aging_promotesLowToHighWhenVeryOld_soSnapshotShowsItInHighSection() throws Exception {
        PriorityDoctorInbox inbox = new PriorityDoctorInbox("D1", 10);

        long now = System.currentTimeMillis();

        // Según tu código:
        // BAJO -> ALTO si wait >= 120 min
        // BAJO -> MEDIO si wait >= 15 min
        // MEDIO -> ALTO si wait >= 45 min
        //
        // Creamos un BAJO con 200 min de antigüedad => debería promover a ALTO.
        long veryOld = now - (200L * 60_000L);

        inbox.enqueue(new PhotoMsg("oldLow", "D1", PhotoMsg.Urgency.BAJO, veryOld));
        inbox.enqueue(new PhotoMsg("newHigh", "D1", PhotoMsg.Urgency.ALTO, now));

        List<QueueUpdate.QueueItem> ordered = inbox.snapshotOrdered();
        List<String> codes = ordered.stream().map(i -> i.imageCode).toList();

        // Ambos deberían aparecer en la sección ALTO, y oldLow debería ir antes por createdAt más viejo
        assertEquals(List.of("oldLow", "newHigh"), codes);
        assertEquals("ALTO", ordered.get(0).urgency);
        assertEquals("ALTO", ordered.get(1).urgency);
    }

    @Test
    void aging_promotesMediumToHighWhenOldEnough() throws Exception {
        PriorityDoctorInbox inbox = new PriorityDoctorInbox("D1", 10);

        long now = System.currentTimeMillis();
        long oldMed = now - (60L * 60_000L); // 60 min => MEDIO -> ALTO (umbral 45)

        inbox.enqueue(new PhotoMsg("oldMed", "D1", PhotoMsg.Urgency.MEDIO, oldMed));
        inbox.enqueue(new PhotoMsg("high", "D1", PhotoMsg.Urgency.ALTO, now));

        List<QueueUpdate.QueueItem> ordered = inbox.snapshotOrdered();
        List<String> codes = ordered.stream().map(i -> i.imageCode).toList();

        // oldMed debería ser ALTO y además primero por más antiguo
        assertEquals(List.of("oldMed", "high"), codes);
        assertEquals("ALTO", ordered.get(0).urgency);
    }
}
