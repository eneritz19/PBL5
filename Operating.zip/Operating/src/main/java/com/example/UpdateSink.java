package com.example;

public interface UpdateSink {
    void push(QueueUpdate update);
}
